/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../TCP_Chat_Server/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[29];
    char stringdata0[417];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "startServer"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 12), // "QHostAddress"
QT_MOC_LITERAL(4, 37, 7), // "address"
QT_MOC_LITERAL(5, 45, 4), // "port"
QT_MOC_LITERAL(6, 50, 10), // "stopServer"
QT_MOC_LITERAL(7, 61, 12), // "selectedRoom"
QT_MOC_LITERAL(8, 74, 5), // "index"
QT_MOC_LITERAL(9, 80, 18), // "newConnectionAdded"
QT_MOC_LITERAL(10, 99, 23), // "std::shared_ptr<Client>"
QT_MOC_LITERAL(11, 123, 6), // "client"
QT_MOC_LITERAL(12, 130, 11), // "acceptError"
QT_MOC_LITERAL(13, 142, 28), // "QAbstractSocket::SocketError"
QT_MOC_LITERAL(14, 171, 5), // "error"
QT_MOC_LITERAL(15, 177, 11), // "listenError"
QT_MOC_LITERAL(16, 189, 7), // "addRoom"
QT_MOC_LITERAL(17, 197, 4), // "name"
QT_MOC_LITERAL(18, 202, 14), // "changeRoomName"
QT_MOC_LITERAL(19, 217, 7), // "newName"
QT_MOC_LITERAL(20, 225, 14), // "addClientNames"
QT_MOC_LITERAL(21, 240, 25), // "std::shared_ptr<ChatRoom>"
QT_MOC_LITERAL(22, 266, 4), // "room"
QT_MOC_LITERAL(23, 271, 16), // "removeClientName"
QT_MOC_LITERAL(24, 288, 29), // "on_button_StartServer_clicked"
QT_MOC_LITERAL(25, 318, 28), // "on_button_StopServer_clicked"
QT_MOC_LITERAL(26, 347, 29), // "on_button_BackToRooms_clicked"
QT_MOC_LITERAL(27, 377, 27), // "on_list_Rooms_doubleClicked"
QT_MOC_LITERAL(28, 405, 11) // "QModelIndex"

    },
    "MainWindow\0startServer\0\0QHostAddress\0"
    "address\0port\0stopServer\0selectedRoom\0"
    "index\0newConnectionAdded\0"
    "std::shared_ptr<Client>\0client\0"
    "acceptError\0QAbstractSocket::SocketError\0"
    "error\0listenError\0addRoom\0name\0"
    "changeRoomName\0newName\0addClientNames\0"
    "std::shared_ptr<ChatRoom>\0room\0"
    "removeClientName\0on_button_StartServer_clicked\0"
    "on_button_StopServer_clicked\0"
    "on_button_BackToRooms_clicked\0"
    "on_list_Rooms_doubleClicked\0QModelIndex"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   84,    2, 0x06 /* Public */,
       6,    0,   89,    2, 0x06 /* Public */,
       7,    1,   90,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       9,    1,   93,    2, 0x0a /* Public */,
      12,    1,   96,    2, 0x0a /* Public */,
      15,    0,   99,    2, 0x0a /* Public */,
      16,    1,  100,    2, 0x0a /* Public */,
      18,    2,  103,    2, 0x0a /* Public */,
      20,    1,  108,    2, 0x0a /* Public */,
      23,    1,  111,    2, 0x0a /* Public */,
      24,    0,  114,    2, 0x08 /* Private */,
      25,    0,  115,    2, 0x08 /* Private */,
      26,    0,  116,    2, 0x08 /* Private */,
      27,    1,  117,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3, QMetaType::UShort,    4,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    8,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void, 0x80000000 | 13,   14,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   17,
    QMetaType::Void, QMetaType::QString, QMetaType::Int,   19,    8,
    QMetaType::Void, 0x80000000 | 21,   22,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28,    8,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->startServer((*reinterpret_cast< const QHostAddress(*)>(_a[1])),(*reinterpret_cast< const quint16(*)>(_a[2]))); break;
        case 1: _t->stopServer(); break;
        case 2: _t->selectedRoom((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 3: _t->newConnectionAdded((*reinterpret_cast< const std::shared_ptr<Client>(*)>(_a[1]))); break;
        case 4: _t->acceptError((*reinterpret_cast< QAbstractSocket::SocketError(*)>(_a[1]))); break;
        case 5: _t->listenError(); break;
        case 6: _t->addRoom((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->changeRoomName((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 8: _t->addClientNames((*reinterpret_cast< std::shared_ptr<ChatRoom>(*)>(_a[1]))); break;
        case 9: _t->removeClientName((*reinterpret_cast< std::shared_ptr<Client>(*)>(_a[1]))); break;
        case 10: _t->on_button_StartServer_clicked(); break;
        case 11: _t->on_button_StopServer_clicked(); break;
        case 12: _t->on_button_BackToRooms_clicked(); break;
        case 13: _t->on_list_Rooms_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QAbstractSocket::SocketError >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(const QHostAddress & , const quint16 & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::startServer)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::stopServer)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const int & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::selectedRoom)) {
                *result = 2;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 14)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 14;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::startServer(const QHostAddress & _t1, const quint16 & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::stopServer()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void MainWindow::selectedRoom(const int & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
