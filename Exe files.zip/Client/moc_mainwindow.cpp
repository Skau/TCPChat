/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../TCP_Chat_Client/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[32];
    char stringdata0[402];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "sendMessage"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 7), // "message"
QT_MOC_LITERAL(4, 32, 9), // "sendImage"
QT_MOC_LITERAL(5, 42, 11), // "QByteArray&"
QT_MOC_LITERAL(6, 54, 2), // "ba"
QT_MOC_LITERAL(7, 57, 12), // "disconnected"
QT_MOC_LITERAL(8, 70, 8), // "joinRoom"
QT_MOC_LITERAL(9, 79, 8), // "roomName"
QT_MOC_LITERAL(10, 88, 10), // "startVoice"
QT_MOC_LITERAL(11, 99, 8), // "endVoice"
QT_MOC_LITERAL(12, 108, 10), // "addMessage"
QT_MOC_LITERAL(13, 119, 8), // "addImage"
QT_MOC_LITERAL(14, 128, 4), // "name"
QT_MOC_LITERAL(15, 133, 23), // "std::shared_ptr<QImage>"
QT_MOC_LITERAL(16, 157, 5), // "image"
QT_MOC_LITERAL(17, 163, 10), // "addClients"
QT_MOC_LITERAL(18, 174, 20), // "std::vector<QString>"
QT_MOC_LITERAL(19, 195, 5), // "names"
QT_MOC_LITERAL(20, 201, 7), // "addRoom"
QT_MOC_LITERAL(21, 209, 10), // "joinedRoom"
QT_MOC_LITERAL(22, 220, 13), // "onSendMessage"
QT_MOC_LITERAL(23, 234, 29), // "on_actionDisconnect_triggered"
QT_MOC_LITERAL(24, 264, 21), // "showCustomContextMenu"
QT_MOC_LITERAL(25, 286, 3), // "pos"
QT_MOC_LITERAL(26, 290, 13), // "sendPMTrigger"
QT_MOC_LITERAL(27, 304, 27), // "on_list_Rooms_doubleClicked"
QT_MOC_LITERAL(28, 332, 11), // "QModelIndex"
QT_MOC_LITERAL(29, 344, 5), // "index"
QT_MOC_LITERAL(30, 350, 27), // "on_button_sendImage_clicked"
QT_MOC_LITERAL(31, 378, 23) // "on_button_Voice_clicked"

    },
    "MainWindow\0sendMessage\0\0message\0"
    "sendImage\0QByteArray&\0ba\0disconnected\0"
    "joinRoom\0roomName\0startVoice\0endVoice\0"
    "addMessage\0addImage\0name\0"
    "std::shared_ptr<QImage>\0image\0addClients\0"
    "std::vector<QString>\0names\0addRoom\0"
    "joinedRoom\0onSendMessage\0"
    "on_actionDisconnect_triggered\0"
    "showCustomContextMenu\0pos\0sendPMTrigger\0"
    "on_list_Rooms_doubleClicked\0QModelIndex\0"
    "index\0on_button_sendImage_clicked\0"
    "on_button_Voice_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       6,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,
       4,    1,  107,    2, 0x06 /* Public */,
       7,    0,  110,    2, 0x06 /* Public */,
       8,    1,  111,    2, 0x06 /* Public */,
      10,    0,  114,    2, 0x06 /* Public */,
      11,    0,  115,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    1,  116,    2, 0x0a /* Public */,
      13,    2,  119,    2, 0x0a /* Public */,
      17,    1,  124,    2, 0x0a /* Public */,
      20,    1,  127,    2, 0x0a /* Public */,
      21,    1,  130,    2, 0x0a /* Public */,
      22,    0,  133,    2, 0x08 /* Private */,
      23,    0,  134,    2, 0x08 /* Private */,
      24,    1,  135,    2, 0x08 /* Private */,
      26,    0,  138,    2, 0x08 /* Private */,
      27,    1,  139,    2, 0x08 /* Private */,
      30,    0,  142,    2, 0x08 /* Private */,
      31,    0,  143,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    3,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 15,   14,   16,
    QMetaType::Void, 0x80000000 | 18,   19,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   25,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 28,   29,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sendMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 1: _t->sendImage((*reinterpret_cast< QByteArray(*)>(_a[1]))); break;
        case 2: _t->disconnected(); break;
        case 3: _t->joinRoom((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->startVoice(); break;
        case 5: _t->endVoice(); break;
        case 6: _t->addMessage((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->addImage((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< std::shared_ptr<QImage>(*)>(_a[2]))); break;
        case 8: _t->addClients((*reinterpret_cast< const std::vector<QString>(*)>(_a[1]))); break;
        case 9: _t->addRoom((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 10: _t->joinedRoom((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 11: _t->onSendMessage(); break;
        case 12: _t->on_actionDisconnect_triggered(); break;
        case 13: _t->showCustomContextMenu((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 14: _t->sendPMTrigger(); break;
        case 15: _t->on_list_Rooms_doubleClicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 16: _t->on_button_sendImage_clicked(); break;
        case 17: _t->on_button_Voice_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::sendMessage)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(QByteArray & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::sendImage)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::disconnected)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::joinRoom)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::startVoice)) {
                *result = 4;
                return;
            }
        }
        {
            using _t = void (MainWindow::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&MainWindow::endVoice)) {
                *result = 5;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void MainWindow::sendMessage(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void MainWindow::sendImage(QByteArray & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void MainWindow::disconnected()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void MainWindow::joinRoom(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void MainWindow::startVoice()
{
    QMetaObject::activate(this, &staticMetaObject, 4, nullptr);
}

// SIGNAL 5
void MainWindow::endVoice()
{
    QMetaObject::activate(this, &staticMetaObject, 5, nullptr);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
